package com.example.temp;

import androidx.appcompat.app.AppCompatActivity;

import android.animation.ValueAnimator;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Shader;
import android.os.Bundle;

import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Random;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import org.w3c.dom.Text;


public class MainActivity extends AppCompatActivity {

    private EditText editText1;
    private TextView wynik;
    private Spinner lista;
    private Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText1 = findViewById(R.id.editText1);
        wynik = findViewById(R.id.wynik);
        lista = findViewById(R.id.lista);
        button = findViewById(R.id.button);
        TextView textView = findViewById(R.id.baner);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.temperatury, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        lista.setAdapter(adapter);

        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                oblicz();
            }
        });

    }

    private void oblicz(){
        double temp1 = Double.parseDouble(editText1.getText().toString());
        double temp2;
        String wybor = lista.getSelectedItem().toString();
        String[] opcje = wybor.split(" => ");

        if (opcje[0].equals("°C") && opcje[1].equals("K")){
            temp2 = temp1 + 273.15;
        } else if(opcje[0].equals("°C") && opcje[1].equals("°F")){
            temp2 = (temp1 * 9/5) + 32;
        } else if (opcje[0].equals("°F") && opcje[1].equals("°C")){
            temp2 = (temp1 - 32) * 5/9;
        } else if (opcje[0].equals("°F") && opcje[1].equals("K")){
            temp2 = (temp1 - 32) * 5/9 + 273.15;
        } else if (opcje[0].equals("K") && opcje[1].equals("°C")){
            temp2 = temp1 - 273.15;
        } else {
            temp2 = (temp1 - 273.15) * 9/5 + 32;
        }

        wynik.setText(String.valueOf(temp2));
    }

    


}